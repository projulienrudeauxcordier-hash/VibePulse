VIBEPULSE — MODE PARTAGÉ + APPELS RÉELS

1. Installer Node.js 18+.
2. Dans ce dossier :
   npm init -y
   npm install express socket.io cors
3. Lancer :
   node vibepulse-server.js
4. Ouvrir :
   http://localhost:3000/

PARTAGE DES VIDÉOS
- Le localStorage du navigateur est PRIVÉ à chaque appareil.
- Pour que les vidéos/Shorts soient visibles par tout le monde, il faut les mettre dans vibepulse-catalog.json ou utiliser POST /api/catalog/merge.
- Les vidéos YouTube n'ont pas besoin d'être téléchargées : le serveur stocke leur youtubeId, titre, miniature, etc.
- Les fichiers vidéo locaux doivent eux aussi être hébergés sur une URL publique (cloud/CDN) pour que les autres utilisateurs puissent les lire.

APPELS
- Le serveur fournit Socket.IO pour la signalisation WebRTC.
- Les deux utilisateurs doivent ouvrir l'application depuis le même serveur public.
- Pour Internet réel, déploie le serveur sur Render/Railway/VPS et mets l'URL dans le réglage "Serveur appels" de VibePulse.
- WebRTC nécessite HTTPS en production (sauf localhost) pour caméra/micro.

ATTENTION
Le fichier HTML seul ne peut pas rendre son localStorage public à tous les utilisateurs. Le serveur est indispensable pour le catalogue partagé et les appels inter-appareils.
